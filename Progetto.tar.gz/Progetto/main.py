# main.py
import threading
from deezer_api import DeezerAPI
from GUI import MusicGUI
from br_listener import BTController

ARL = 'b9792e1bd287213121107fae6699d01f945fe991e9924a376c455117e71cba170ece53229beb18c0f6ffcc20bc3cdcea3d86f80cac8bbb88c5b88c51e8fd1ae08b1c56d70e672bbf8e2a4fb8c3374eb9f35cd0d3a8d1bbef47518078605f0d66'  # Inserisci qui il tuo valore ARL

if __name__ == "__main__":
    deezer = DeezerAPI(ARL)
    gui = MusicGUI(deezer)

    bt = BTController(gui)
    bt_thread = threading.Thread(target=bt.start, daemon=True)
    bt_thread.start()

    gui.run()
