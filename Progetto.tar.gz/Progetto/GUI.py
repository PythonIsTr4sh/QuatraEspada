# gui.py
import tkinter as tk
import tkinter.simpledialog as simpledialog
from vlc import MediaPlayer

class MusicPlayer:
    def __init__(self):
        self.player = MediaPlayer()
        self.queue = []
        self.index = 0

    def set_queue(self, tracks):
        self.queue = tracks
        self.index = 0

    def play(self):
        if not self.queue:
            return
        url = self.queue[self.index].get('preview')
        if url:
            self.player.set_mrl(url)
            self.player.play()
            return self.queue[self.index]

    def next(self):
        if not self.queue:
            return
        self.index = (self.index + 1) % len(self.queue)
        return self.play()

class MusicGUI:
    def __init__(self, api):
        self.api = api
        self.player = MusicPlayer()

        self.window = tk.Tk()
        self.window.title("Deezer Controller")

        self.track_label = tk.Label(self.window, text="Nessuna traccia")
        self.track_label.pack(pady=10)

        btn_frame = tk.Frame(self.window)
        btn_frame.pack()
        tk.Button(btn_frame, text="Play Query", command=self.play_query).pack(side=tk.LEFT, padx=5)
        tk.Button(btn_frame, text="Next", command=self.next_track).pack(side=tk.LEFT, padx=5)

    def play_query(self):
        query = simpledialog.askstring("Search", "Inserisci il nome della traccia o artista:")
        if not query:
            return
        tracks = self.api.search_track(query)
        if tracks:
            self.player.set_queue(tracks)
            track = self.player.play()
            self.track_label.config(text=f"Riproduzione: {track['title']} - {track['artist']['name']}")

    def play(self):
        track = self.player.play()
        if track:
            self.track_label.config(text=f"Riproduzione: {track['title']} - {track['artist']['name']}")

    def next_track(self):
        track = self.player.next()
        if track:
            self.track_label.config(text=f"Riproduzione: {track['title']} - {track['artist']['name']}")

    def run(self):
        self.window.mainloop()
