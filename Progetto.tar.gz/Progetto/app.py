from flask import Flask, request, jsonify, send_from_directory
import threading
import logging

# Importa i moduli esistenti
from deezer_api import DeezerAPI
from GUI import MusicGUI
from br_listener import BTController

# ARL token Deezer
ARL = 'b9792e1bd287213121107fae6699d01f945fe991e9924a376c455117e71cba170ece53229beb18c0f6ffcc20bc3cdcea3d86f80cac8bbb88c5b88c51e8fd1ae08b1c56d70e672bbf8e2a4fb8c3374eb9f35cd0d3a8d1bbef47518078605f0d66'

# Configurazione logging
logging.basicConfig(level=logging.INFO)

# Inizializza le classi
deezer = DeezerAPI(ARL)
gui = MusicGUI(deezer)

# Avvia anche il listener bluetooth in un thread (opzionale)
bt = BTController(gui)
bt_thread = threading.Thread(target=bt.start, daemon=True)
bt_thread.start()

# Flask setup
app = Flask(__name__, static_folder='static')

# Serve la pagina HTML
@app.route('/')
def index():
    return send_from_directory('static', 'index.html')

# Endpoint per PLAY (con ricerca)
@app.route('/play', methods=['POST'])
def play():
    query = request.form.get('query')
    if not query:
        logging.warning("Play chiamato senza query")
        return ('Missing query', 400)

    tracks = deezer.search_track(query)
    if not tracks:
        logging.info(f"Nessuna traccia trovata per query: {query}")
        return ('Nessuna traccia trovata', 404)

    gui.player.set_queue(tracks)
    track = gui.player.play()
    if not track:
        logging.error("Errore nella riproduzione della traccia")
        return ('Errore nella riproduzione', 500)

    # Prendo la cover dal campo album
    cover_url = track.get('album', {}).get('cover_medium')
    response = {
        'title':  track['title'],
        'artist': track['artist']['name'],
        'album':  { 'cover': cover_url }
    }
    logging.info(f"Riproduzione: {response}")
    return jsonify(response)

# Endpoint per NEXT
@app.route('/next', methods=['POST'])
def next_track():
    track = gui.player.next()
    if not track:
        logging.info("Nessuna traccia in coda per NEXT")
        return ('Nessuna traccia in coda', 400)

    cover_url = track.get('album', {}).get('cover_medium')
    response = {
        'title':  track['title'],
        'artist': track['artist']['name'],
        'album':  { 'cover': cover_url }
    }
    logging.info(f"Next: {response}")
    return jsonify(response)

# Avvio del server
if __name__ == '__main__':
    context = ('cert.pem', 'key.pem')
    app.run(host='0.0.0.0', port=8443, ssl_context=context)
