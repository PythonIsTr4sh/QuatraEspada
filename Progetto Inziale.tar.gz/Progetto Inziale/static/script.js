    const statusDiv = document.getElementById('status');
    const queryInput = document.getElementById('query');
    const albumImageContainer = document.getElementById('album-image-container');
    const albumImage = document.getElementById('album-image');

    const PASSWORD = '74739';

    async function sendCommand(cmd, body = null) {
      try {
        const options = { method: 'POST' };

        body.pwd = PASSWORD;

        if (body !== null) {
          options.headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
          options.body = new URLSearchParams(body);
        }
        const res = await fetch(`/${cmd}`, options);
        if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);
        const data = await res.json();
        statusDiv.textContent = 'Comando inviato all’host.';
        albumImageContainer.style.display = 'none';
      } catch (err) {
        statusDiv.textContent = `Errore: ${err.message}`;
      }
    }

    document.getElementById('play-btn').addEventListener('click', () => {
      const q = queryInput.value.trim();
      if (!q) {
        statusDiv.textContent = 'Inserisci una query prima di premere Play.';
        return;
      }
      sendCommand('play', { query: q });
    });

    document.getElementById('next-btn').addEventListener('click', () => {
      sendCommand('next');
    });

    document.getElementById('prev-btn').addEventListener('click', () => {
      sendCommand('prev');
    });