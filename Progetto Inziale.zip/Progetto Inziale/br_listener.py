import bluetooth
import logging

class BTController:
    def __init__(self, gui):
        self.gui = gui
        self.server_sock = None
        self.client_sock = None
        self.is_running = True

    def start(self):
        self.server_sock = bluetooth.BluetoothSocket(bluetooth.RFCOMM)
        self.server_sock.bind(("", bluetooth.PORT_ANY))
        self.server_sock.listen(1)

        port = self.server_sock.getsockname()[1]
        # bluetooth.advertise_service(
        #    self.server_sock,
        #    "MusicControlService",
        #    service_classes=[bluetooth.SERIAL_PORT_CLASS],
        #    profiles=[bluetooth.SERIAL_PORT_PROFILE]
        # )

        logging.info(f"[BT] In attesa di connessioni Bluetooth sul canale {port}...")

        try:
            self.client_sock, client_info = self.server_sock.accept()
            logging.info(f"[BT] Connessione accettata da {client_info}")

            while self.is_running:
                data = self.client_sock.recv(1024).decode('utf-8').strip().lower()
                if not data:
                    continue

                logging.info(f"[BT] Ricevuto comando: {data}")

                if data == 'play':
                    self.gui.player.play()
                elif data == 'next':
                    self.gui.player.next()
                elif data == 'prev':
                    self.gui.player.previous()
                elif data == 'stop':
                    self.is_running = False
                else:
                    logging.warning(f"[BT] Comando sconosciuto: {data}")

        except OSError as e:
            logging.error(f"[BT] Errore: {e}")

        finally:
            if self.client_sock:
                self.client_sock.close()
            if self.server_sock:
                self.server_sock.close()
            logging.info("[BT] Connessione Bluetooth chiusa")
