const statusDiv = document.getElementById('status');
const queryInput = document.getElementById('query');
const albumImageContainer = document.getElementById('album-image-container');
const albumImage = document.getElementById('album-image');

const PASSWORD = '74739';

async function sendCommand(cmd, body = null) {
  try {
    const options = { method: 'POST' };

    if (body !== null) {
      body.pwd = PASSWORD;
      options.headers = { 'Content-Type': 'application/x-www-form-urlencoded' };
      options.body = new URLSearchParams(body);
    }

    const res = await fetch(`/${cmd}`, options);
    if (!res.ok) throw new Error(`${res.status} ${res.statusText}`);

    const data = await res.json();

    // Mostra titolo e artista nella status
    if (data.title && data.artist) {
      statusDiv.textContent = `Play: "${data.title}" di ${data.artist}`;
    } else {
      statusDiv.textContent = 'Comando inviato all’host.';
    }

    // Se c’è immagine album la mostro
    if (data.album && data.album.cover) {
      albumImage.src = data.album.cover;
      albumImageContainer.style.display = 'block';
    } else {
      albumImageContainer.style.display = 'none';
    }

  } catch (err) {
    statusDiv.textContent = `Errore: ${err.message}`;
  }
}

document.getElementById('play-btn').addEventListener('click', () => {
  const q = queryInput.value.trim();
  if (!q) {
    statusDiv.textContent = 'Inserisci una query prima di premere Play.';
    return;
  }
  sendCommand('play', { query: q });
});

document.getElementById('next-btn').addEventListener('click', () => {
  sendCommand('next');
});

document.getElementById('prev-btn').addEventListener('click', () => {
  sendCommand('prev');
});