# deezer_api.py
import requests

class DeezerAPI:
    def __init__(self, arl):
        self.session = requests.Session()
        self.session.cookies.set('arl', arl)
        self.base_url = 'https://www.deezer.com/ajax/gw-light.php'

    def _api_call(self, method, input_params=None):
        params = {
            'api_version': '1.0',
            'api_token': 'null',
            'input': '3',
            'method': method,
        }
        if input_params:
            params.update(input_params)
        res = self.session.get(self.base_url, params=params)
        return res.json()

    def search_track(self, query, limit=10):
        res = self.session.get('https://api.deezer.com/search', params={'q': query, 'limit': limit})
        return res.json().get('data', [])
