# br_listener.py
import bluetooth

class BTController:
    def __init__(self, gui):
        self.gui = gui

    def start(self):
        server = bluetooth.BluetoothSocket(bluetooth.RFCOMM)
        server.bind(("", bluetooth.PORT_ANY))
        server.listen(1)
        client, addr = server.accept()
        print("Bluetooth connesso a", addr)

        while True:
            data = client.recv(1024).decode().strip()
            if data == "PLAY":
                self.gui.play()
            elif data == "NEXT":
                self.gui.next_track()
